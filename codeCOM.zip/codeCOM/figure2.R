# Script pour la figure2 
#"The autumnal lockdown was not the main initiator of the decrease in the level of SARS-CoV-2 circulation in France" 
# D. Pierron 
# version = mars 2021

# ouvertures des bibliotheques 
library(ggplot2)
library(plyr)
library("openxlsx")
library("reshape2");library(lubridate)
library("ggpubr")
library(scales)
library(stringr)
library(tidyverse)
library(rgdal)
library(broom)
library(reshape2)
library(stringr)
library(zoo)
library(ggthemes)
library(grid)
library(gridExtra)
library(cowplot)
Sys.setlocale(locale = "en_US.UTF-8")  # calendrier AMERICAIN

###########################
#https://www.data.gouv.fr/en/datasets/donnees-des-urgences-hospitalieres-et-de-sos-medecins-relatives-a-lepidemie-de-covid-19/
URGENCE=read.table("~/Documents/PROJETS/13_COVID/covid_HIVER/dataGOUV/sursaud-corona-quot-dep-2021-02-25-19h20.csv",sep=";",header=TRUE)
#https://www.data.gouv.fr/en/datasets/donnees-hospitalieres-relatives-a-lepidemie-de-covid-19/
hosp=read.table("~/Documents/PROJETS/13_COVID/covid_HIVER/dataGOUV/donnees-hospitalieres-nouveaux-covid19-2021-02-25-19h03.csv",sep=";",header=TRUE)
#https://www.data.gouv.fr/en/datasets/donnees-relatives-aux-resultats-des-tests-virologiques-covid-19/
pcr=read.table("~/Documents/PROJETS/13_COVID/covid_HIVER/dataGOUV/sp-pos-quot-dep-2021-02-25-19h20.csv",sep=";",header=TRUE)


D=levels(factor(URGENCE$dep))
#Paris and suburbs; Marseille, Lyon, Lille, Saint-Etienne, Rouen, Toulouse, Grenoble and Montpellier.
Paris=c("75","77","78","91","92","93","94","95")
Marseille="13";Lyon="69";Lille="59";SaintEtienne="42";Rouen="76";Toulouse="31"; Grenoble="38"; Montpellier="34"
dep1=c(Paris,Marseille, Lyon, Lille, SaintEtienne, Rouen, Toulouse, Grenoble, Montpellier)
dep2=c("87","84","83","82","81","74","73","71","67","66","65","64","62","60","54","51","49","48","45","43","39","37","35","30","26","21","2B","2A","14","12","10","09","08","07","06","05","01")
dep3=subset(D,!D %in%  c(dep1,dep2) )

########

URGENCE2=subset(URGENCE,!URGENCE$dep %in% c("971","972","973","974","976"))
hosp2=subset(hosp,!hosp$dep %in% c("971","972","973","974","976"))
pcr2=subset(pcr,!pcr$dep %in% c("971","972","973","974","976"))
#### tous les ages 
URGENCE2=subset(URGENCE2,URGENCE2$sursaud_cl_age_corona == "0" )
pcr2=subset(pcr2,pcr$cl_age90 == "0")

URGENCE2$tempo="Area 3"
URGENCE2[URGENCE2$dep%in%dep1,"tempo"]="Area 1"
URGENCE2[URGENCE2$dep%in%dep2,"tempo"]="Area 2"

hosp2$tempo="Area 3"
hosp2[hosp2$dep%in%dep1,"tempo"]="Area 1"
hosp2[hosp2$dep%in%dep2,"tempo"]="Area 2"

pcr2$tempo="Area 3"
pcr2[pcr2$dep%in%dep1,"tempo"]="Area 1"
pcr2[pcr2$dep%in%dep2,"tempo"]="Area 2"

######### ratio ER
URGENCE2$ratio=URGENCE2$nbre_pass_corona/URGENCE2$nbre_pass_tot
pcr2$ratio=pcr2$P/pcr2$T


limiteDEB=as.Date("2020-10-01")
limiteFIN=as.Date("2020-12-29")

######### CALCUL DEPARTEMENT PAR DEPARTEMENT 

lDEP=levels(factor(URGENCE2$dep))
# departement par departement
nn=0
gg=0
for (d in lDEP){print(d);
	
	######ETAPE 1 : DONNEE URGENCES
	UR=URGENCE2[URGENCE2$dep==d,c("date_de_passage","ratio","dep","tempo","nbre_hospit_corona")]
	UR$ratioM=rollapply(UR$ratio, width = 7, FUN = mean, fill = NA, align = "center")
	UR$ratioM2=UR$ratioM/max(UR$ratioM,na.rm=TRUE)
	######
	UR$hospM=rollapply(UR$nbre_hospit_corona, width = 7, FUN = mean, fill = NA, align = "center")
	UR$hospM2=UR$ratioM/max(UR$hospM,na.rm=TRUE)
	##### pic 
	URX=subset(UR,as.Date(UR$date_de_passage)> limiteDEB & as.Date(UR$date_de_passage)  < limiteFIN )
	maxi=URX[which.max(URX$ratioM),] ; maxi$type="urgence"
	maxi2=URX[which.max(URX$hospM),]  ; maxi2$type="hosp"
	if(d==lDEP[1]){maxL=rbind(maxi,maxi2)}else{maxL=rbind(maxL,maxi,maxi2)}
	
	######ETAPE 2a : DONNEE pcrS
	PC=pcr2[pcr2$dep==d,c("jour","P","dep","tempo","ratio")]
	PC$positifM=rollapply(PC$P, width = 7, FUN = mean, fill = NA, align = "center")
	PC$positifM2=PC$positifM/max(PC$positifM,na.rm=TRUE)
	######
	PC$ratioM=rollapply(PC$ratio, width = 7, FUN = mean, fill = NA, align = "center")
	PC$ratioM2=PC$ratioM/max(PC$ratioM,na.rm=TRUE)
	##### pic 
	PCX=subset(PC,as.Date(PC$jour)> limiteDEB & as.Date(PC$jour)< limiteFIN )
	maxiRATIO_PCR=PCX[which.max(PCX$ratioM),] ; maxiRATIO_PCR$type="ratio"
	maxiPOSITIF_PCR=PCX[which.max(PCX$positifM2),]  ; maxiPOSITIF_PCR$type="nb"
	if(d==lDEP[1]){maxiPCRt=rbind(maxiRATIO_PCR,maxiPOSITIF_PCR)}else{maxiPCRt=rbind(maxiPCRt,maxiRATIO_PCR,maxiPOSITIF_PCR)}	
	
	######ETAPE 2 :  DONNEE HOSPITALIERES
	hospX=hosp2[hosp2$dep==d,c("jour","dep","incid_hosp","incid_rea","incid_dc","tempo")]
	for (evt in c("incid_hosp","incid_rea","incid_dc")){
	evt2=paste(evt,"MY",sep="");evt3=paste(evt2,"rel",sep="");
	hospX[,evt2]=rollapply(hospX[,evt], width = 7, FUN = mean, fill = NA, align = "center")
	hospX[,evt3]=hospX[,evt2]/max(hospX[,evt2],na.rm=TRUE)
	## pic
	hospXX=subset(hospX,as.Date(hospX$jour) > limiteDEB  & as.Date(hospX$jour) < limiteFIN  )
	maxiHOSP=hospXX[which.max(hospXX[,evt3]),c("jour","dep","incid_hosp","incid_rea","incid_dc","tempo")] ; maxiHOSP$type=evt
	nn=nn+1
	if (nn==1){maxiHOOO=maxiHOSP}else{maxiHOOO=rbind(maxiHOOO,maxiHOSP)}
	}
	
	##### ETAPE 3 : DONNEE GOOGLE
	if (1>3){
	for (terme in c("perte gout","perte odorat")){
		zone=paste("FR-",d,sep="")
		google = gtrends(keyword = terme ,geo = zone,onlyInterest=TRUE,time="2020-03-01 2020-11-23" )$interest_over_time
		if (length(google>0)){
		google$hitsM=rollapply(google$hits, width = 7, FUN = mean, fill = NA, align = "center")
		google$hitsM2=google$hitsM/max(google$hitsM,na.rm=TRUE)
		google$dep=d
		googMAX=subset(google,as.Date(google$date)> as.Date("2020-10-01"))
		maxiGOOG=googMAX[which.max(googMAX$hitsM2),] 
		gg=gg+1
		if (gg==1){googleX=google;maxiGOOGtot=maxiGOOG}else{googleX=rbind(googleX,google);maxiGOOGtot=rbind(maxiGOOG,maxiGOOGtot)}}
	}}

	###### ETAPE 4 : ENREGISTRMENT PAR TYPES DE DONNEES
	if(d==lDEP[1]){tot=UR; HOO=hospX ;PCRRR=PC }else{tot=rbind(UR,tot); HOO=rbind(HOO,hospX );PCRRR=rbind(PC,PCRRR) }	
	# les maxi s'enregistre a part
}

###############################################
maxL$date=as.Date(maxL$date_de_passage)
maxiHOOO$date=as.Date(maxiHOOO$jour)
maxiPCRt$date=as.Date(maxiPCRt$jour)
maxA=maxL[,c("type","tempo","date","dep")]
maxB=maxiHOOO[,c("type","tempo","date","dep")]
maxD=maxiPCRt[,c("type","tempo","date","dep")]

##########

maxC=rbind(maxA,maxB,maxD)

maxC$type2=revalue(maxC$type,c("urgence"="ER COVID-19 ratio", "ratio"= "Positive PCRs (ratio)", "nb"= "Positive PCRs (number)","incid_rea"= "CCRU adm.","incid_hosp"= "Hospital adm.","incid_dc"= "Deaths","hosp"= "Hospital adm. post ER"))
maxC$type2=factor(maxC$type2,levels=c("Deaths", "CCRU adm.","Hospital adm.","hosp"="Hospital adm. post ER","ER COVID-19 ratio","Positive PCRs (number)","ratio"= "Positive PCRs (ratio)"))

maxC$tempo2=factor(maxC$tempo,levels=c("Area 3","Area 2", "Area 1"))
maxC$tempo2=revalue(maxC$tempo2,c("Area 3"="No curfew","Area 2"="October 24", "Area 1"="October 17"))

A=ggplot(data=maxC)+geom_boxplot(aes(x=type2,y=as.Date(date),color=tempo2))+scale_color_manual("Overnight Curfew:",values = c("#33a02c","#1f78b4","#e31a1c"),guide=FALSE)
C=A+scale_y_date("", date_labels = "%b %d",date_breaks = "10 days",minor_breaks="1 days")+ theme(axis.text.x=element_text(hjust=1,vjust=0.2))
C=C+coord_flip()+theme_bw()+xlab("")
figureB=C+ theme(legend.position="none")

nnn=0
for (t in levels(factor(maxC$type2))){
	print(t)
	maxT=subset(maxC,maxC$type2==t)
	A= subset(maxT,maxT$tempo=="Area 1")
	B= subset(maxT,maxT$tempo=="Area 2")
	C= subset(maxT,maxT$tempo=="Area 3")
	A=as.numeric(A$date);B=as.numeric(B$date);C=as.numeric(C$date);
	Ttest=data.frame(indicator=t,AB=t.test(A,B)[[3]],AC=t.test(A,C)[[3]],BC=t.test(B,C)[[3]])
	nnn=nnn+1
	if (nnn==1){Ttest1=Ttest}else{Ttest1=rbind(Ttest,Ttest1)}
}

#########################################################################
########################################################################

#Graphique DEPARTEMENT :
FRANCEd <- readOGR(dsn = "~/Documents/PROJETS/13_COVID/projet_FRANCE/2_donneeGEO/GEO/dep2014shp/", layer = "departements-20140306-100m")
FRANCE_tidy <- tidy(FRANCEd)
FRANCEd$id=as.character(row.names(FRANCEd))
d=FRANCEd$code_insee  ; d[nchar(d)==1]=paste("0",d[nchar(d)==1],sep="")
FRANCEd$dep=paste("DEP-",d,sep="")

dep1b=dep1
dep1b[nchar(dep1b)==1]=paste("0",dep1b[nchar(dep1b)==1],sep="")
dep1b=paste("DEP-",dep1,sep="")
########
dep2b=dep2
dep2b[nchar(dep2b)==1]=paste("0",dep2b[nchar(dep2b)==1],sep="")
dep2b=paste("DEP-",dep2,sep="")
########
dep3b=dep3
dep3b[nchar(dep3b)==1]=paste("0",dep3b[nchar(dep3b)==1],sep="")
dep3b=paste("DEP-",dep3,sep="")


########################### INFO POUR COULEURS 
FRANCEd@data$couleur="0"
FRANCEd@data$couleur[FRANCEd$dep%in%dep1b]="October 17"
FRANCEd@data$couleur[FRANCEd$dep%in%dep2b]="October 24"
FRANCEd@data$couleur[FRANCEd$dep%in%dep3b]="No curfew"
FRANCEd@data$couleur=factor(FRANCEd@data$couleur,levels=c("October 17","October 24","No curfew"))
FRANCE_tidy[,c("id","dep","nom","couleur")]=FRANCEd@data[as.character(FRANCE_tidy$id),c("id","nom","dep","couleur")]
METRO=subset(FRANCE_tidy,FRANCE_tidy$lat>0 &FRANCE_tidy$long>-20)
CARTE=ggplot() + geom_polygon(data=METRO, aes(x = long, y = lat, group = group,fill=couleur),color=NA, size = 0.1) + coord_map()
CARTE2=CARTE+theme_void() +theme(aspect.ratio = 1)#+ theme(legend.position="none")
CARTE2=CARTE2+scale_fill_manual("Overnight curfew:",values = c("#e31a1c","#1f78b4","#33a02c"))+ theme(legend.position="none")

legend_b <- get_legend(CARTE2 +guides(color = guide_legend(nrow = 1)) +theme(legend.position = "bottom"))


PROW=plot_grid(CARTE2, figureB, labels = c('A', 'B'), label_size = 12, ncol = 2, rel_widths   = c(30, 50))
plot_grid(PROW, legend_b, ncol = 1, rel_heights = c(1, .1))






#########################################################################
#########################################################################
#########################################################################
A=data.frame(date=as.Date(HOO$jour)-14, tempo=HOO$tempo, valeur=HOO$incid_hospMYrel,na.rm=TRUE)
B=data.frame(date=as.Date(HOO$jour)-14, tempo=HOO$tempo, valeur=HOO$incid_reaMYrel,na.rm=TRUE)
C=data.frame(date=as.Date(HOO$jour)-19, tempo=HOO$tempo, valeur=HOO$incid_dcMYrel,na.rm=TRUE)
D=data.frame(date=as.Date(tot$date_de_passage)-11, tempo=tot$tempo, valeur=tot$ratioM2,na.rm=TRUE)


global=rbind(D)
Summary=aggregate(global$valeur,by=list(dateCOR=global$date,tempo=global$tempo),FUN=mean,na.rm=TRUE)
Summary$sd=aggregate(global$valeur,by=list(dateCOR=global$date,tempo=global$tempo),FUN=sd,na.rm=TRUE)$x
Summary$min=Summary$x-Summary$sd
Summary$max=Summary$x+Summary$sd
Summary$Indicators="Composite indicator"


restrictions=data.frame(tempo=c("Area 1","Area 2"),date=c("2020-10-17","2020-10-24"))


A= ggplot(data=tot2)
####### CONFINEMENT
A= A + geom_rect(xmin=as.Date("2020-03-17"), xmax=as.Date("2020-05-11"), ymin=-0.2 , ymax=1.2,fill="#fee08b",alpha=0.2)
A= A + geom_rect(xmin=as.Date("2020-10-30"), xmax=as.Date("2020-11-12"), ymin=-0.2 , ymax=1.2,fill="#fee08b",alpha=0.2)
A= A + geom_rect(xmin=as.Date("2020-10-17"), xmax=as.Date("2020-10-30"), ymin=-0.2 , ymax=1.2,fill="#ffffbf",alpha=0.2)
A= A + geom_rect(xmin=as.Date("2020-05-11"), xmax=as.Date("2020-07-10"), ymin=-0.2 , ymax=1.2,fill="#ffffbf",alpha=0.2)

A= A+geom_vline(data=restrictions,aes(xintercept=as.Date(date),linetype="Curfew"))
################
# DATA
A=A+geom_ribbon(data=Summary,aes(ymin =min, ymax = max,x=dateCOR, fill =factor(tempo)),alpha=0.5)

A=A+geom_line(data=Summary,aes(x=dateCOR,y=x,color=factor(tempo)))
#A=A+geom_line(data=BILANX,aes(x=date2-11,y=hospM2,color=factor(tempo)),linetype="dashed")
#A=A+geom_ribbon(data=hosp,aes(ymin =myA, ymax = myB,x=date2-11, fill =factor(tempo)),alpha=0.5)

A=A+facet_wrap(tempo~.,scales="free",ncol=1)

A=A+scale_color_manual("Areas",values = c("#e31a1c","#1f78b4","#33a02c"),guide=F)+scale_fill_manual("area",values = c("#e31a1c","#1f78b4","#33a02c"),guide=F)+theme_bw() 
D=A+scale_linetype_manual("Events",values="dashed")+xlab("Date")+ylab(" indicator")
test=data.frame(tempo="Area 1")
D=D+ geom_label(data=test,label="Lc", x=as.Date("2020-04-15"), y=0.8,fill="#fee08b")
D=D+ geom_label(data=test,label="Es", x=as.Date("2020-06-15"), y=0.8,fill="#ffffbf")
D=D+ geom_label(data=test,label="Lc", x=as.Date("2020-11-05"), y=0.8,fill="#fee08b")
D=D+ geom_label(data=test,label="Es", x=as.Date("2020-10-22"), y=0.8,fill="#ffffbf")
figure1=D

#scale_linetype_discrete()

#+geom_line(aes(x=date2-11,y=my,color=factor(tempo)))

############### figure 1 : courbe et map 

haut=plot_grid(CARTE2,figure2, align = "h",axis = "bt", nrow = 2, rel_heights   = c(50/100, 40/100), labels = c('A','B'), label_size = 12)

plot_grid(haut, figure1, labels = c('', 'C'), label_size = 12, ncol = 2, rel_widths   = c(50, 100))















####### COURBE URGENCE
tot2=aggregate(tot$ratioM2,by=list(date=tot$date_de_passage,tempo=tot$tempo),FUN=mean,na.rm=TRUE)
tot2$my=aggregate(tot$ratioM2,by=list(date=tot$date_de_passage,tempo=tot$tempo),FUN=mean,na.rm=TRUE)$x
tot2$sd=aggregate(tot$ratioM2,by=list(date=tot$date_de_passage,tempo=tot$tempo),FUN=sd,na.rm=TRUE)$x
tot2$myA=tot2$my+tot2$sd
tot2$myB=tot2$my-tot2$sd
tot2$date2=as.Date(tot2$date)

####### COURBE HOSP
hosp=aggregate(tot$hospM2,by=list(date=tot$date_de_passage,tempo=tot$tempo),FUN=mean,na.rm=TRUE)
hosp$my=aggregate(tot$hospM2,by=list(date=tot$date_de_passage,tempo=tot$tempo),FUN=mean,na.rm=TRUE)$x
hosp$sd=aggregate(tot$hospM2,by=list(date=tot$date_de_passage,tempo=tot$tempo),FUN=sd,na.rm=TRUE)$x
hosp$myA=hosp$my+hosp$sd
hosp$myB=hosp$my-hosp$sd
hosp$date2=as.Date(hosp$date)






