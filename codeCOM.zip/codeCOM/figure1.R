# Script pour la figure 1 
#"The autumnal lockdown was not the main initiator of the decrease in the level of SARS-CoV-2 circulation in France" 
# D. Pierron 
# version = mars 2021

# ouvertures des bibliotheques 
library(gtrendsR)
library(lubridate)
library(tidyr)
library(ggplot2)
library(scales)
library(plyr)
library(zoo, warn.conflicts = FALSE)
library(cowplot)
library("openxlsx")

### definition de fonctions 
rollingSlope.lm.fit <- function(vector) {vector2=vector[!is.na(vector)]; a <- coef(.lm.fit(cbind(1,seq(vector2)), vector2))[2] ; return(a) }
augementation <- function(vector) {a=vector[1];b=vector[2];c=b/a;return(c)}
pic2=function(a){b=a[a$date >as.Date("2020-06-01"),] ; c=b[which.max(b$nbMY2),c("date","dateCOR")] ;return(c)}

### calendrier americain pour les graph 
Sys.setlocale(locale = "en_US.UTF-8")  # calendrier AMERICAIn
limitFIN="2021-01-01"
CONFINEMENT1=as.Date("2020-03-17")


##  ETAPE 1 : TELECHARGEMENT DES DONNEES GOOGLE 

nn=0
for (terme in c("perte gout","perte odorat")){
############ la periode globale #######
# on telecharge en 2 fois "overlaps"
complet1 = gtrends(keyword = terme ,geo = "FR",onlyInterest=TRUE,time="2020-03-01 2020-11-01" )$interest_over_time
complet2 = gtrends(keyword = terme ,geo = "FR",onlyInterest=TRUE,time=paste("2020-05-15","2021-01-20") )$interest_over_time
row.names(complet2)=complet2$date ; row.names(complet1)=complet1$date 
commun = as.character(complet1$date[complet1$date %in%  complet2$date])
comparaison=data.frame(date=commun, tempA=complet1[commun,"hits"],tempB=complet2[commun,"hits"])
Reg=lm(comparaison$tempA ~ comparaison$tempB) ; ratio=as.numeric(coefficients(Reg)[[2]])
complet2$hits2=complet2$hits*ratio ; complet1$hits2=complet1$hits
completT=rbind(complet2,complet1)
complet=aggregate(completT$hits2,by=list(date=completT$date),FUN=mean)
complet$hits=complet$x
#########
complet$terme=terme
complet$date2=as.character(complet$date)
row.names(complet)=complet$date
#######
complet$nbMY=rollapply(complet$hits, width = 7, FUN = mean, fill = NA, align = "center")
complet$nbMY2=complet$nbMY/max(complet$nbMY,na.rm=TRUE)
####
complet$hits7slope=rollapply(complet$nbMY2, width = 7, FUN = rollingSlope.lm.fit , fill = NA, align = "center")
#######
complet$augementationBRUT=rollapply(complet$hits, width = 7, FUN = augementation, fill = NA, align = "center")
complet$augementationBRUTmoyenne=rollapply(complet$augementationBRUT, width = 7, FUN = mean, fill = NA, align = "center")
#######
complet$augementationMOYENNE=rollapply(complet$nbMY2, width = 7, FUN = augementation, fill = NA, align = "center")
complet$augementationMOYENNEm=rollapply(complet$augementationMOYENNE, width = 7, FUN = mean, fill = 1, align = "center")

########@
nn=nn+1
if(nn==1){google=complet}else{google=rbind(google,complet)}
}


google$dateX=as.Date(google$date)



############################################
##  ETAPE 2 : PREPARATION DONNEES HOSPITALIERES

hosp=read.table("~/Documents/PROJETS/13_COVID/covid_HIVER/dataGOUV/donnees-hospitalieres-nouveaux-covid19-2021-02-25-19h03.csv",sep=";",header=TRUE)
hospFR=aggregate(hosp[,c("incid_hosp","incid_rea","incid_dc","incid_rad")],by=list(date=hosp$jour),FUN=sum)

for (evt in c("incid_hosp","incid_rea","incid_dc","incid_rad")){
	evt2=paste(evt,"MY",sep="");evt3=paste(evt2,"rel",sep="");
	hospFR[,evt2]=rollapply(hospFR[,evt], width = 7, FUN = mean, fill = NA, align = "center")
	hospFR[,evt3]=hospFR[,evt2]/max(hospFR[,evt2],na.rm=TRUE)
}
hospFR$date2=as.Date(hospFR$date)


############ DONNEE GEODE ##########
URGENCE=read.table("~/Documents/PROJETS/13_COVID/covid_HIVER/dataGOUV/sursaud-corona-quot-dep-2021-02-25-19h20.csv",sep=";",header=TRUE)
URGENCE2=subset(URGENCE,URGENCE$sursaud_cl_age_corona == "0" )

UR=aggregate(URGENCE2[,c("nbre_pass_corona","nbre_pass_tot")],by=list(date=URGENCE2$date_de_passage),FUN=sum,na.rm=TRUE)

UR$ratio=UR$nbre_pass_corona/UR$nbre_pass_tot


UR$ratioM=rollapply(UR$ratio, width = 7, FUN = mean, fill = NA, align = "center")
UR$ratioM2=UR$ratioM/max(UR$ratioM,na.rm=TRUE)
######
#UR$hospM=rollapply(UR$nbre_hospit_corona, width = 7, FUN = mean, fill = NA, align = "center")
#UR$hospM2=UR$ratioM/max(UR$hospM,na.rm=TRUE)

	
	

############################################
##  ETAPE 3 : PREPARATION DONNEES DU QUESTIONNAIRE ODORAT 


Lyon=read.xlsx("~/Documents/PROJETS/13_COVID/covid_HIVER/doneelyon/results-survey146862.xlsx",rowNames=TRUE)
head(Lyon[,1:3])
##grep("date",names(Lyon),value=TRUE)
ODORAT="datemodiodorat..Quand.cette.modification.est-elle.apparue.?"   
 
odorat=as.data.frame(table(Lyon[,c(ODORAT)]))
odorat$date=as.Date(odorat$Var1);odorat=subset(odorat,odorat$date> as.Date("2020-03-01"))
odorat$nbMY=rollapply(odorat$Freq, width = 7, FUN = mean, fill = NA, align = "center")
odorat$nbMY2=odorat$nbMY/max(odorat$nbMY,na.rm=TRUE)

MALADIE="datecoviddebu..Indiquez.la.date.de.début.de.la.maladie"  
covid=as.data.frame(table(Lyon[,c(MALADIE)]))
covid$date=as.Date(covid$Var1);covid=subset(covid,covid$date> as.Date("2020-03-01"))
covid$nbMY=rollapply(covid$Freq, width = 7, FUN = mean, fill = NA, align = "center")
covid$nbMY2=covid$nbMY/max(covid$nbMY,na.rm=TRUE)



############################################
##  ETAPE 4 : LES PICS

tableau=bilan

###############
URG=data.frame(date=as.Date(UR$date),nb=0, nbREL=0, nbMY2=UR$ratioM2, augementationMOYENNEm=0,terme="urgences",type="governmental data")
URG$type="governmental data"
URG=subset(URG,!is.na(URG$nbMY2))
PIC=URG[URG$nbMY2==1,"date"]
Diff_URG=PIC-CONFINEMENT1
URG$dateCOR =  URG$date -  Diff_URG

bilan=cbind(data.frame("pic"=PIC,decalage=Diff_URG,type="urgence"),pic2(URG))
tableau=bilan

###############
OD1=subset(google,google$terme %in% c("perte odorat"))
OD2=data.frame(date=OD1$dateX,nb=OD1$hits, nbREL=OD1$hits, nbMY2=OD1$nbMY2, augementationMOYENNEm=OD1$augementationMOYENNEm,terme="perte odorat",type="independant data")
OD3=subset(OD2,!is.na(OD2$nbMY2))
PIC=OD3[OD3$nbMY2==1,"date"]
Diff_OD3=PIC-CONFINEMENT1
OD3$dateCOR =  OD3$date -  Diff_OD3

bilan=cbind(data.frame("pic"=PIC,decalage=Diff_OD3,type="odorat GOOGLE"),pic2(OD3))
tableau=rbind(tableau,bilan)



############################################################
GST1=subset(google,google$terme %in% c("perte gout"))
GST2=data.frame(date=GST1$dateX,nb=GST1$hits, nbREL=GST1$hits, nbMY2=GST1$nbMY2, augementationMOYENNEm=GST1$augementationMOYENNEm,terme="perte gout",type="independant data")
GST3=subset(GST2,!is.na(GST2$nbMY2))
PIC=GST3[GST3$nbMY2==1,"date"][1]
Diff_GST3=PIC-CONFINEMENT1
GST3$dateCOR =  GST3$date -  Diff_GST3


bilan=cbind(data.frame("pic"=PIC,decalage=Diff_GST3,type="gout GOOGLE"),pic2(GST3))
tableau=rbind(tableau,bilan)


############### REA de hosp

REA2=data.frame(date=hospFR$date2,nb=0, nbREL=0, nbMY2=hospFR$incid_reaMYrel, augementationMOYENNEm=0,terme="rea2",type="governmental data")
REA2=subset(REA2,!is.na(REA2$nbMY2))
PIC=REA2[REA2$nbMY2==1,"date"]
Diff_REA2=PIC-CONFINEMENT1
REA2$dateCOR =  REA2$date -  Diff_REA2


bilan=cbind(data.frame("pic"=PIC,decalage=Diff_REA2,type="rea2"),pic2(REA2))
tableau=rbind(tableau,bilan)


admHOSP=data.frame(date=hospFR$date2,nb=0, nbREL=0, nbMY2=hospFR$incid_hospMYrel, augementationMOYENNEm=0,terme="admHOSP",type="governmental data")
admHOSP=subset(admHOSP,!is.na(admHOSP$nbMY2))
PIC=admHOSP[admHOSP$nbMY2==1,"date"]
Diff_admHOSP=PIC-CONFINEMENT1
admHOSP$dateCOR =  admHOSP$date -  Diff_admHOSP


bilan=cbind(data.frame("pic"=PIC,decalage=Diff_admHOSP,type="admHOSP"),pic2(admHOSP))
tableau=rbind(tableau,bilan)

dcHOSP=data.frame(date=hospFR$date2,nb=0, nbREL=0, nbMY2=hospFR$incid_dcMYrel, augementationMOYENNEm=0,terme="dc",type="governmental data")
dcHOSP=subset(dcHOSP,!is.na(dcHOSP$nbMY2))
PIC=dcHOSP[dcHOSP$nbMY2==1,"date"]
Diff_dcHOSP=PIC-CONFINEMENT1
dcHOSP$dateCOR =  dcHOSP$date -  Diff_dcHOSP


bilan=cbind(data.frame("pic"=PIC,decalage=Diff_dcHOSP,type="dcHOSP"),pic2(dcHOSP))
tableau=rbind(tableau,bilan)


############################################################
odoratLYON=data.frame(date=odorat$date,nb=0, nbREL=0, nbMY2=odorat$nbMY2, augementationMOYENNEm=0,terme="Report of change in smell (- 4 days)",type="independant data")
odoratLYON=subset(odoratLYON,!is.na(odoratLYON$nbMY2))
PIC=odoratLYON[odoratLYON$nbMY2==1,"date"]
Diff_odoratLYON=PIC-CONFINEMENT1
odoratLYON$dateCOR =  odoratLYON$date -  Diff_odoratLYON

bilan=cbind(data.frame("pic"=PIC,decalage=Diff_odoratLYON,type="odoratLYON"),pic2(odoratLYON))
tableau=rbind(tableau,bilan)



covidLYON=data.frame(date=covid$date,nb=0, nbREL=0, nbMY2=covid$nbMY2, augementationMOYENNEm=0,terme="COVID first symptoms",type="independant data")
covidLYON=subset(covidLYON,!is.na(covidLYON$nbMY2))
PIC=covidLYON[covidLYON$nbMY2==1,"date"]
Diff_covidLYON=PIC-CONFINEMENT1
covidLYON$dateCOR =  covidLYON$date -  Diff_covidLYON


bilan=cbind(data.frame("pic"=PIC,decalage=Diff_covidLYON,type="covidLYON"),pic2(covidLYON))
tableau=rbind(tableau,bilan)


tableau[order(tableau$decalage),]

odoratLYONterme=paste(odoratLYON$terme,"(-",Diff_covidLYON,"days)",sep="")
covidLYON$terme=paste(covidLYON$terme,"(-",Diff_covidLYON,"days)",sep="")


############################################
##  ETAPE 5 : INDICATEUR GLOBAL

global=rbind(REA2,URG,OD3,GST3,dcHOSP,admHOSP,odoratLYON) #covidLYON,
global=global[,c("terme","nbMY2","dateCOR","type")]


global2=subset(global,!is.na(global$nbMY2))
Summary=aggregate(global2$nbMY2,by=list(dateCOR=global2$dateCOR),FUN=length)
Summary$nbMY2=aggregate(global2$nbMY2,by=list(dateCOR=global2$dateCOR),FUN=mean,na.rm=TRUE)$x
Summary$Indicators="Composite indicator"
Summary=subset(Summary,Summary$x==7)
Summary$type="independant data"


############################################################
############################################
##  ETAPE 6 : FIGURE

# FIGURE
confinementL=data.frame(date=c(as.Date("2020-03-17"),as.Date("2020-10-30")),event=c("National Lockdown","National Lockdown"),country="FRANCE")

global$Indicators=revalue(global$terme,c("dc"="Deaths (-19 days)","admHOSP"="Hospital adm. (-14 days)","rea2"="CCRU adm. (-14 days)" ,"perte gout"="Google- Loss of taste (-6 days)","perte odorat"="Google- Loss of smell  (-6 days)" , "urgences"="ER consultation (-11 days)"))


test=data.frame()
globalA=subset(global,global$type=="governmental data")
A=ggplot(data=globalA)#+facet_wrap(Indicators~.,ncol=1)
A= A + geom_rect(xmin=as.Date("2020-03-17"), xmax=as.Date("2020-05-11"), ymin=-0.2 , ymax=1.2,fill="#fee08b",alpha=0.1)
A= A + geom_rect(xmin=as.Date("2020-10-30"), xmax=as.Date("2020-12-15"), ymin=-0.2 , ymax=1.2,fill="#fee08b",alpha=0.1)
A= A + geom_rect(xmin=as.Date("2020-10-17"), xmax=as.Date("2020-10-30"), ymin=-0.2 , ymax=1.2,fill="#ffffbf",alpha=0.1)
A= A + geom_rect(xmin=as.Date("2020-05-11"), xmax=as.Date("2020-07-10"), ymin=-0.2 , ymax=1.2,fill="#ffffbf",alpha=0.1)
A= A + geom_rect(xmin=as.Date("2020-12-15"), xmax=as.Date("2020-12-31"), ymin=-0.2 , ymax=1.2,fill="#ffffbf",alpha=0.1)
A=A+ geom_label(data=test,aes(label="Lockdown", x=as.Date("2020-04-15")), y=0.97,fill="#fee08b")
A=A+ geom_label(data=test,aes(label="State of emergency", x=as.Date("2020-06-10")), y=0.97,fill="#ffffbf")
A=A+ geom_label(data=test,aes(label="Lockdown", x=as.Date("2020-11-25")), y=0.97,fill="#fee08b")
A=A+ geom_label(data=test,aes(label="SoE", x=as.Date("2020-10-22")), y=0.97,fill="#ffffbf")
A=A+geom_line(aes(x=dateCOR,y=nbMY2,color=Indicators))

A=A+ scale_y_continuous("")#,labels = scales::percent
D=A+xlab("Date")+scale_color_manual("Governemental\n indicators",values = c("grey50","#e41a1c","#a65628","#4daf4a","#984ea3","#ff7f00","#377eb8","black","red"))
fig1=D+theme_classic() +scale_x_date("",date_breaks = "2 months",limits = c(as.Date("2020-03-01"),as.Date(limitFIN)), date_labels = "%B")+theme(strip.background = element_blank(),axis.text.x = element_blank())

globalB=subset(global,global$type=="independant data")
A=ggplot(data=globalB)#+facet_wrap(Indicators~.,ncol=1)
A= A + geom_rect(xmin=as.Date("2020-03-17"), xmax=as.Date("2020-05-11"), ymin=-0.2 , ymax=1.2,fill="#fee08b",alpha=0.1)
A= A + geom_rect(xmin=as.Date("2020-10-30"), xmax=as.Date("2020-12-15"), ymin=-0.2 , ymax=1.2,fill="#fee08b",alpha=0.1)
A= A + geom_rect(xmin=as.Date("2020-10-17"), xmax=as.Date("2020-10-30"), ymin=-0.2 , ymax=1.2,fill="#ffffbf",alpha=0.1)
A= A + geom_rect(xmin=as.Date("2020-05-11"), xmax=as.Date("2020-07-10"), ymin=-0.2 , ymax=1.2,fill="#ffffbf",alpha=0.1)
A= A + geom_rect(xmin=as.Date("2020-12-15"), xmax=as.Date("2020-12-31"), ymin=-0.2 , ymax=1.2,fill="#ffffbf",alpha=0.1)
A=A+geom_line(aes(x=dateCOR,y=nbMY2, color=Indicators))
A=A+ scale_y_continuous("                                  Viral circulation (relative scale)")#,labels = scales::percent
D=A+xlab("Date")+scale_color_manual("Population based\n indicators",values = c("#66a61e","#7570b3","#1b9e77","#e7298a"))
fig2=D+theme_classic() +scale_x_date("",date_breaks = "2 months",limits = c(as.Date("2020-03-01"),as.Date(limitFIN)), date_labels = "%B")+theme(strip.background = element_blank(),axis.text.x = element_blank())




############################################################
############################################################

rollingSlope.lm.fit <- function(vector) {vector2=vector[!is.na(vector)]; a <- coef(.lm.fit(cbind(1,seq(vector2)), vector2))[2] ; return(a) }
augementation <- function(vector) {a=vector[1];b=vector[2];c=b/a;return(c)}

Summary$slope=rollapply(Summary$nbMY2, width = 7, FUN = rollingSlope.lm.fit , fill = NA, align = "center")
Summary$augementation=rollapply(Summary$nbMY2, width = 7, FUN = augementation  , fill = NA, align = "center")

Summary2=subset(Summary,!is.na(Summary$slope))
A=ggplot(Summary2)
A= A + geom_rect(xmin=as.Date("2020-03-17"), xmax=as.Date("2020-05-11"), ymin=-0.2 , ymax=1.2,fill="#fee08b",alpha=0.1)
A= A + geom_rect(xmin=as.Date("2020-10-30"), xmax=as.Date("2020-12-15"), ymin=-0.2 , ymax=1.2,fill="#fee08b",alpha=0.1)
A= A + geom_rect(xmin=as.Date("2020-10-17"), xmax=as.Date("2020-10-30"), ymin=-0.2 , ymax=1.2,fill="#ffffbf",alpha=0.1)
A= A + geom_rect(xmin=as.Date("2020-05-11"), xmax=as.Date("2020-07-10"), ymin=-0.2 , ymax=1.2,fill="#ffffbf",alpha=0.1)
A= A + geom_rect(xmin=as.Date("2020-12-15"), xmax=as.Date("2020-12-31"), ymin=-0.2 , ymax=1.2,fill="#ffffbf",alpha=0.1)
A=A+geom_bar(data=Summary2,aes(x=dateCOR,y=slope,fill=slope),stat="identity", width=1)
A=A+geom_line(data=Summary2,aes(x=dateCOR,y=slope),color=muted("yellow"))
A=A+geom_hline(yintercept=0,color="black")
A=A+theme_classic()  +theme(axis.line.x = element_blank())+scale_x_date("Date",date_breaks = "2 months",limits = c(as.Date("2020-03-01"),as.Date(limitFIN)), date_labels = "%B")


fig3=A+xlab("Date")+ylab("Slope")+scale_fill_gradientn("Slope of composite\n indicator",colours = c("#0571b0","#92c5de","#f7f7f7","#f4a582","#d6604d","#ca0020"),breaks=c(-0.05,0,0.05))


plot_grid(fig1 + theme(legend.justification = c(0,1)),fig2 + theme(legend.justification = c(0,1)),fig3 + theme(legend.justification = c(0,1)), labels = c('           A','           B', '           C'), label_size = 12, ncol = 1, align = 'v', rel_heights   = c(50, 50,50))

tableau[order(tableau$decalage),]


